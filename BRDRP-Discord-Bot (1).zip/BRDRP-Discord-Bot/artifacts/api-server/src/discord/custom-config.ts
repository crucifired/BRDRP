export type WordAction = "delete" | "warn" | "timeout" | "kick" | "ban";

const defaultAutoReplies: Record<string, string> = {
  hello: "Hello! Welcome to BRDRP | Border RP.",
  hi: "Hi! Welcome to BRDRP.",
  rules: "Use /rules to view the BRDRP community rules.",
  help: "Use /rules for the rules or /server-info for server information.",
};

function parseAutoReplies(): Record<string, string> {
  const raw = process.env["BRDRP_AUTO_REPLIES"];
  if (!raw) return defaultAutoReplies;

  try {
    const parsed: unknown = JSON.parse(raw);
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
      return defaultAutoReplies;
    }

    return Object.fromEntries(
      Object.entries({
        ...defaultAutoReplies,
        ...parsed,
      }).filter(
        ([trigger, reply]) =>
          trigger.trim().length > 0 &&
          typeof reply === "string" &&
          reply.trim().length > 0,
      ),
    );
  } catch {
    return defaultAutoReplies;
  }
}

export function getBlockedWords(): string[] {
  return (process.env["BRDRP_BLOCKED_WORDS"] ?? "")
    .split(",")
    .map((word) => word.trim().toLocaleLowerCase())
    .filter(Boolean);
}

export function getWordAction(): WordAction {
  const value = process.env["BRDRP_WORD_ACTION"];
  return value === "warn" ||
    value === "timeout" ||
    value === "kick" ||
    value === "ban"
    ? value
    : "delete";
}

export function getAutoReplies(): Record<string, string> {
  return parseAutoReplies();
}