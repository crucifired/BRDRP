# BRDRP Discord bot

This project contains the first BRDRP bot for the **BRDRP | Border RP** Discord server.
It is designed for the Emergency Hamburg roleplay community and runs alongside the
API service.

## Included commands

- `/ping` — confirms the bot is online.
- `/server-info` — shows basic BRDRP server information.
- `/rules` — displays the community rules.
- `/announce message:<text>` — staff-only announcement in the current channel.
- `/clear amount:<1-100>` — staff-only message cleanup.
- `/call-911 situation:<text> location:<text>` — posts an Emergency Hamburg roleplay callout.
- `/ban user:<member> reason:<text>` — staff-only permanent ban.
- `/kick user:<member> reason:<text>` — staff-only kick.
- `/mute user:<member> minutes:<number> reason:<text>` — staff-only temporary mute (Discord timeout).
- `/staff-infract user:<member> infraction:<⚠️ Verbal Warning|⚠️ Warning 1|⚠️ Warning 2|⚠️ Warning 3|⚠️ Strike 1|⚠️ Strike 2|⚠️ Strike 3|⚠️ Suspended Staff|⚠️ Terminated|⚠️ Blacklist> reason:<text>` — adds the selected staff infraction role; usable in any chat by `Internal Affairs`.
- `/staff-promotion user:<member> old-role:<role> new-role:<role> reason:<text>` — replaces the old role with any new role, including `Trial Ownership`, as part of the promotion system; usable in any chat by an `Ownership` rank.

## Discord Developer Portal setup

1. Create an application at <https://discord.com/developers/applications>.
2. Open **Bot**, create the bot, and copy its token into the Replit Secret named
   `DISCORD_BOT_TOKEN`. Never paste the token into a file or chat.
3. Under **OAuth2 → URL Generator**, select the `bot` and `applications.commands`
   scopes.
4. Give the bot these permissions:
   - View Channels
   - Send Messages
   - Embed Links
   - Read Message History
   - Manage Messages (needed for `/clear`)
    - Manage Roles (needed for `/staff-infract` and `/staff-promotion`)
5. Open the generated invite URL and add the bot to **BRDRP | Border RP**.
6. In **Bot → Privileged Gateway Intents**, enable **Message Content Intent**.

The bot's highest role must be above every role it should issue. Staff command access is
controlled by the issuer's Discord role: the exact `Internal Affairs` role for infractions
and any role whose name contains `Ownership` for promotions.

The bot is configured for BRDRP's server ID by default. To use another server, set
the non-secret `DISCORD_GUILD_ID` environment variable.

## Optional configuration

- `BRDRP_RULES` — replaces the default rules shown by `/rules`.
- `BRDRP_EMERGENCY_CHANNEL_ID` — sends `/call-911` reports to a dedicated dispatch
  channel instead of the channel where the command was used.
- `BRDRP_ENABLE_MESSAGE_FILTER` — set to `true` after enabling Message Content Intent
  in the Discord Developer Portal. This turns on word filtering and auto-replies.
- `BRDRP_BLOCKED_WORDS` — comma-separated words or phrases to remove, for example
  `word-one,word-two`.
- `BRDRP_WORD_ACTION` — what happens after a blocked message: `delete` (default),
  `warn`, `timeout`, `kick`, or `ban`. `timeout` applies a 5-minute timeout.
  Start with `delete` or `warn` while testing.
- Members with the roles `Owner`, `Founder`, `Co Founder`, `Co Owner`, `Trial Ownership`,
  or `Server Developer` are exempt from the 5-minute timeout. Their blocked messages are
  still deleted.
- `BRDRP_AUTO_REPLIES` — JSON object mapping phrases to replies, for example
  `{"hello":"Welcome to BRDRP!","how do I join":"Use /rules first."}`.

After the bot is invited, restart the API service once. Slash commands are registered
to the configured server automatically.