import {
  Client,
  EmbedBuilder,
  Events,
  GatewayIntentBits,
  PermissionFlagsBits,
  REST,
  Routes,
  type ChatInputCommandInteraction,
  type GuildMember,
  type Guild,
} from "discord.js";
import { logger } from "../lib/logger";
import { getAutoReplies, getBlockedWords, getWordAction } from "./custom-config";

const defaultGuildId = "1472261826573111428";
const guildId = process.env["DISCORD_GUILD_ID"] ?? defaultGuildId;
const botToken = process.env["DISCORD_BOT_TOKEN"];
const wordFilterTimeoutExemptRoles = new Set([
  "owner",
  "founder",
  "co founder",
  "co owner",
  "trial ownership",
  "server developer",
]);

const commands = [
  {
    name: "ping",
    description: "Check that the BRDRP bot is online.",
  },
  {
    name: "server-info",
    description: "Show basic information about the BRDRP Discord server.",
  },
  {
    name: "rules",
    description: "Show the current BRDRP community rules.",
  },
  {
    name: "announce",
    description: "Send a staff announcement in the current channel.",
    options: [
      {
        type: 3,
        name: "message",
        description: "The announcement to send.",
        required: true,
      },
    ],
    default_member_permissions: String(PermissionFlagsBits.ManageGuild),
  },
  {
    name: "clear",
    description: "Delete recent messages from the current channel.",
    options: [
      {
        type: 4,
        name: "amount",
        description: "Number of messages to delete, from 1 to 100.",
        required: true,
        min_value: 1,
        max_value: 100,
      },
    ],
    default_member_permissions: String(PermissionFlagsBits.ManageMessages),
  },
  {
    name: "call-911",
    description: "Create an Emergency Hamburg roleplay callout.",
    options: [
      {
        type: 3,
        name: "situation",
        description: "What is happening?",
        required: true,
        max_length: 500,
      },
      {
        type: 3,
        name: "location",
        description: "Where is it happening?",
        required: true,
        max_length: 200,
      },
    ],
  },
  {
    name: "ban",
    description: "Ban a member from BRDRP.",
    options: [
      {
        type: 6,
        name: "user",
        description: "The member to ban.",
        required: true,
      },
      {
        type: 3,
        name: "reason",
        description: "Why the member is being banned.",
        required: true,
        max_length: 500,
      },
    ],
    default_member_permissions: String(PermissionFlagsBits.BanMembers),
  },
  {
    name: "kick",
    description: "Kick a member from BRDRP.",
    options: [
      {
        type: 6,
        name: "user",
        description: "The member to kick.",
        required: true,
      },
      {
        type: 3,
        name: "reason",
        description: "Why the member is being kicked.",
        required: true,
        max_length: 500,
      },
    ],
    default_member_permissions: String(PermissionFlagsBits.KickMembers),
  },
  {
    name: "mute",
    description: "Timeout a member temporarily.",
    options: [
      {
        type: 6,
        name: "user",
        description: "The member to mute.",
        required: true,
      },
      {
        type: 4,
        name: "minutes",
        description: "Mute duration in minutes, from 1 to 40320.",
        required: true,
        min_value: 1,
        max_value: 40320,
      },
      {
        type: 3,
        name: "reason",
        description: "Why the member is being muted.",
        required: true,
        max_length: 500,
      },
    ],
    default_member_permissions: String(PermissionFlagsBits.ModerateMembers),
  },
  {
    name: "staff-infract",
    description: "Issue a staff infraction role in the infraction group.",
    options: [
      {
        type: 6,
        name: "user",
        description: "The staff member receiving the infraction.",
        required: true,
      },
      {
        type: 3,
        name: "infraction",
        description: "The infraction role to issue.",
        required: true,
        choices: [
          { name: "⚠️ Verbal Warning", value: "⚠️ Verbal Warning" },
          { name: "⚠️ Warning 1", value: "⚠️ Warning 1" },
          { name: "⚠️ Warning 2", value: "⚠️ Warning 2" },
          { name: "⚠️ Warning 3", value: "⚠️ Warning 3" },
          { name: "⚠️ Strike 1", value: "⚠️ Strike 1" },
          { name: "⚠️ Strike 2", value: "⚠️ Strike 2" },
          { name: "⚠️ Strike 3", value: "⚠️ Strike 3" },
          { name: "⚠️ Suspended Staff", value: "⚠️ Suspended Staff" },
          { name: "⚠️ Terminated", value: "⚠️ Terminated" },
          { name: "⚠️ Blacklist", value: "⚠️ Blacklist" },
        ],
      },
      {
        type: 3,
        name: "reason",
        description: "Why the infraction is being issued.",
        required: true,
        max_length: 500,
      },
    ],
  },
  {
    name: "staff-promotion",
    description: "Replace a staff role with any new role, including Trial Ownership.",
    options: [
      {
        type: 6,
        name: "user",
        description: "The staff member being promoted.",
        required: true,
      },
      {
        type: 8,
        name: "old-role",
        description: "The staff role to remove.",
        required: true,
      },
      {
        type: 8,
        name: "new-role",
        description: "The new role to give the staff member.",
        required: true,
      },
      {
        type: 3,
        name: "reason",
        description: "Why the promotion is being issued.",
        required: true,
        max_length: 500,
      },
    ],
  },
];

function rulesText(): string {
  return (
    process.env["BRDRP_RULES"] ??
    [
      "Respect every community member and keep chat welcoming.",
      "Keep roleplay realistic and follow the server's scene rules.",
      "Do not spam, exploit, harass, or share unsafe content.",
      "Listen to staff instructions and use the proper report channels.",
    ].join("\n")
  );
}

function hasPermission(
  interaction: ChatInputCommandInteraction,
  permission: bigint,
): boolean {
  return Boolean(
    interaction.memberPermissions?.has(permission) ||
      interaction.user.id === interaction.guild?.ownerId,
  );
}

function normalizeDiscordName(value: string): string {
  return value
    .trim()
    .toLocaleLowerCase()
    .replace(/^#/, "")
    .replace(/[-_]+/g, " ")
    .replace(/\s+/g, " ");
}

function hasRoleNamed(member: GuildMember, roleName: string): boolean {
  const normalizedRoleName = roleName.trim().toLocaleLowerCase();
  return member.roles.cache.some(
    (role) => role.name.trim().toLocaleLowerCase() === normalizedRoleName,
  );
}

function hasOwnershipRank(member: GuildMember): boolean {
  return member.roles.cache.some((role) =>
    normalizeDiscordName(role.name).includes("ownership"),
  );
}

function findRoleByName(guild: Guild, roleName: string) {
  const normalizedRoleName = normalizeDiscordName(roleName);
  return (
    guild.roles.cache.find(
      (role) => normalizeDiscordName(role.name) === normalizedRoleName,
    ) ?? null
  );
}

function hasWordFilterTimeoutExemptRole(member: GuildMember): boolean {
  return member.roles.cache.some((role) =>
    wordFilterTimeoutExemptRoles.has(normalizeDiscordName(role.name)),
  );
}

function escapeRegExp(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function containsBlockedWord(content: string, blockedWord: string): boolean {
  const normalizedWord = blockedWord.trim().replace(/\s+/g, " ");
  if (!normalizedWord) return false;

  const matcher = new RegExp(
    `(^|[^\\p{L}\\p{N}])${escapeRegExp(normalizedWord)}($|[^\\p{L}\\p{N}])`,
    "iu",
  );
  return matcher.test(content.trim().replace(/\s+/g, " "));
}

async function applyWordAction(
  message: {
    author: { id: string; tag: string };
    content: string;
    member: GuildMember | null;
    delete: () => Promise<unknown>;
  },
  action: ReturnType<typeof getWordAction>,
): Promise<void> {
  const reason = "Blocked word filter";
  try {
    await message.delete();
  } catch (error) {
    logger.warn(
      { err: error, userId: message.author.id },
      "Word filter could not delete the message; check Manage Messages permission",
    );
  }

  if (
    action === "timeout" &&
    message.member &&
    !hasWordFilterTimeoutExemptRole(message.member)
  ) {
    await message.member.timeout(5 * 60 * 1000, reason);
  } else if (action === "kick" && message.member) {
    await message.member.kick(reason);
  } else if (action === "ban" && message.member) {
    await message.member.ban({ reason });
  }
}

async function handleInteraction(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  if (!interaction.isChatInputCommand()) return;

  switch (interaction.commandName) {
    case "ping":
      await interaction.reply({
        content: "BRDRP bot is online and ready.",
        ephemeral: true,
      });
      return;

    case "server-info": {
      const guild = interaction.guild;
      if (!guild) {
        await interaction.reply({
          content: "This command can only be used inside the BRDRP server.",
          ephemeral: true,
        });
        return;
      }
      await interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(0x1d4ed8)
            .setTitle(`${guild.name} | BRDRP`)
            .setDescription("Emergency Hamburg community hub")
            .addFields(
              {
                name: "Members",
                value: String(guild.memberCount),
                inline: true,
              },
              {
                name: "Created",
                value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:D>`,
                inline: true,
              },
            )
            .setTimestamp(),
        ],
      });
      return;
    }

    case "rules":
      await interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(0x0f766e)
            .setTitle("BRDRP community rules")
            .setDescription(rulesText())
            .setFooter({ text: "Use /report if staff help is needed." }),
        ],
      });
      return;

    case "announce": {
      if (!hasPermission(interaction, PermissionFlagsBits.ManageGuild)) {
        await interaction.reply({
          content: "You need the Manage Server permission to make announcements.",
          ephemeral: true,
        });
        return;
      }

      const message = interaction.options.getString("message", true);
      await interaction.reply({ content: "Announcement sent.", ephemeral: true });
      if (interaction.channel?.isSendable()) {
        await interaction.channel.send({
          embeds: [
            new EmbedBuilder()
              .setColor(0xf59e0b)
              .setTitle("BRDRP staff announcement")
              .setDescription(message)
              .setFooter({ text: `Posted by ${interaction.user.displayName}` })
              .setTimestamp(),
          ],
        });
      }
      return;
    }

    case "clear": {
      if (!hasPermission(interaction, PermissionFlagsBits.ManageMessages)) {
        await interaction.reply({
          content: "You need the Manage Messages permission to clear messages.",
          ephemeral: true,
        });
        return;
      }

      const amount = interaction.options.getInteger("amount", true);
      if (
        !interaction.channel ||
        !interaction.channel.isSendable() ||
        !("bulkDelete" in interaction.channel) ||
        typeof interaction.channel.bulkDelete !== "function"
      ) {
        await interaction.reply({
          content: "This command can only be used in a text channel.",
          ephemeral: true,
        });
        return;
      }

      await interaction.deferReply({ ephemeral: true });
      const deleted = await interaction.channel.bulkDelete(amount, true);
      await interaction.editReply(`Deleted ${deleted.size} message(s).`);
      return;
    }

    case "staff-infract": {
      const guild = interaction.guild;
      if (!guild) {
        await interaction.reply({
          content: "This command can only be used inside the BRDRP server.",
          ephemeral: true,
        });
        return;
      }

      const issuingMember = await guild.members
        .fetch(interaction.user.id)
        .catch(() => null);
      if (!issuingMember || !hasRoleNamed(issuingMember, "Internal Affairs")) {
        await interaction.reply({
          content:
            "Only the exact Internal Affairs role can issue staff infractions.",
          ephemeral: true,
        });
        return;
      }

      const targetUser = interaction.options.getUser("user", true);
      const infractionName = interaction.options.getString("infraction", true);
      const reason = interaction.options.getString("reason", true);
      const role = findRoleByName(guild, infractionName);
      if (!role) {
        await interaction.reply({
          content: `The "${infractionName}" role was not found. Create it first, then try again.`,
          ephemeral: true,
        });
        return;
      }

      const member = await guild.members.fetch(targetUser.id).catch(() => null);
      if (!member) {
        await interaction.reply({
          content: "That user is not a member of this server.",
          ephemeral: true,
        });
        return;
      }

      await interaction.deferReply({ ephemeral: true });
      try {
        await member.roles.add(
          role,
          `Staff infraction by ${interaction.user.tag}: ${reason}`,
        );
      } catch (error) {
        logger.warn(
          { err: error, roleId: role.id, userId: member.id },
          "Staff infraction role could not be added",
        );
        await interaction.editReply(
          "I could not add that role. Check that the bot has Manage Roles and its highest role is above the target role.",
        );
        return;
      }

      if (interaction.channel?.isSendable()) {
        await interaction.channel.send({
          embeds: [
            new EmbedBuilder()
              .setColor(0xdc2626)
              .setTitle("Staff infraction issued")
              .addFields(
                { name: "Author of infraction", value: `<@${member.id}>`, inline: true },
                { name: "Infraction type", value: role.name, inline: true },
                { name: "Reason", value: reason },
                { name: "Staff Member", value: `<@${interaction.user.id}>`, inline: true },
              )
              .setTimestamp(),
          ],
        });
      }
      await interaction.editReply(
        `Issued the ${role.name} role to ${member.user.tag}.`,
      );
      return;
    }

    case "staff-promotion": {
      const guild = interaction.guild;
      if (!guild) {
        await interaction.reply({
          content: "This command can only be used inside the BRDRP server.",
          ephemeral: true,
        });
        return;
      }

      const issuingMember = await guild.members
        .fetch(interaction.user.id)
        .catch(() => null);
      if (!issuingMember || !hasOwnershipRank(issuingMember)) {
        await interaction.reply({
          content: "Only members with an Ownership rank can promote staff.",
          ephemeral: true,
        });
        return;
      }

      const targetUser = interaction.options.getUser("user", true);
      const oldRoleOption = interaction.options.getRole("old-role", true);
      const newRoleOption = interaction.options.getRole("new-role", true);
      const reason = interaction.options.getString("reason", true);
      const [oldRole, newRole] = await Promise.all([
        guild.roles.fetch(oldRoleOption.id).catch(() => null),
        guild.roles.fetch(newRoleOption.id).catch(() => null),
      ]);
      if (!oldRole || !newRole) {
        await interaction.reply({
          content: "The old or new role could not be loaded from this server.",
          ephemeral: true,
        });
        return;
      }
      if (oldRole.id === newRole.id) {
        await interaction.reply({
          content: "The old role and new role must be different.",
          ephemeral: true,
        });
        return;
      }
      const member = await guild.members.fetch(targetUser.id).catch(() => null);
      if (!member) {
        await interaction.reply({
          content: "That user is not a member of this server.",
          ephemeral: true,
        });
        return;
      }
      if (!member.roles.cache.has(oldRole.id)) {
        await interaction.reply({
          content: `${member.user.tag} does not have the ${oldRole.name} role.`,
          ephemeral: true,
        });
        return;
      }
      const alreadyHadNewRole = member.roles.cache.has(newRole.id);

      await interaction.deferReply({ ephemeral: true });
      try {
        await member.roles.add(
          newRole,
          `Staff promotion by ${interaction.user.tag}: ${reason}`,
        );
        await member.roles.remove(
          oldRole,
          `Staff promotion by ${interaction.user.tag}: ${reason}`,
        );
      } catch (error) {
        if (!alreadyHadNewRole) {
          await member.roles.remove(newRole).catch(() => undefined);
        }
        logger.warn(
          { err: error, oldRoleId: oldRole.id, newRoleId: newRole.id, userId: member.id },
          "Staff promotion roles could not be replaced",
        );
        await interaction.editReply(
          "I could not replace those roles. Check that the bot has Manage Roles and its highest role is above both roles.",
        );
        return;
      }

      if (interaction.channel?.isSendable()) {
        await interaction.channel.send({
          embeds: [
            new EmbedBuilder()
              .setColor(0x16a34a)
              .setTitle("Staff promotion issued")
              .addFields(
                { name: "Author of infraction", value: `<@${member.id}>`, inline: true },
                { name: "Old role", value: oldRole.name, inline: true },
                { name: "New role", value: newRole.name, inline: true },
                { name: "Reason", value: reason },
                { name: "Staff Member", value: `<@${interaction.user.id}>`, inline: true },
              )
              .setTimestamp(),
          ],
        });
      }
      await interaction.editReply(
        `Replaced ${oldRole.name} with ${newRole.name} for ${member.user.tag}.`,
      );
      return;
    }

    case "call-911": {
      const situation = interaction.options.getString("situation", true);
      const location = interaction.options.getString("location", true);
      const targetChannelId = process.env["BRDRP_EMERGENCY_CHANNEL_ID"];
      const targetChannel =
        (targetChannelId
          ? await interaction.client.channels.fetch(targetChannelId)
          : interaction.channel) ?? null;

      const embed = new EmbedBuilder()
        .setColor(0xdc2626)
        .setTitle("Emergency Hamburg roleplay call")
        .addFields(
          { name: "Situation", value: situation },
          { name: "Location", value: location },
          { name: "Reported by", value: `<@${interaction.user.id}>` },
        )
        .setFooter({ text: "BRDRP dispatch" })
        .setTimestamp();

      if (targetChannel?.isSendable()) {
        await targetChannel.send({ embeds: [embed] });
        await interaction.reply({
          content: targetChannelId
            ? "Your call has been sent to BRDRP dispatch."
            : "Your call has been posted in this channel.",
          ephemeral: true,
        });
      } else {
        await interaction.reply({
          content:
            "I could not reach the dispatch channel. Ask staff to set BRDRP_EMERGENCY_CHANNEL_ID.",
          ephemeral: true,
        });
      }
      return;
    }

    case "ban": {
      if (!hasPermission(interaction, PermissionFlagsBits.BanMembers)) {
        await interaction.reply({
          content: "You need the Ban Members permission to use this command.",
          ephemeral: true,
        });
        return;
      }
      const member = interaction.options.getMember("user");
      const reason = interaction.options.getString("reason", true);
      if (!member || !("ban" in member) || typeof member.ban !== "function") {
        await interaction.reply({
          content: "That user is not a member of this server.",
          ephemeral: true,
        });
        return;
      }
      await member.ban({ reason });
      await interaction.reply(`Banned ${member.user.tag}. Reason: ${reason}`);
      return;
    }

    case "kick": {
      if (!hasPermission(interaction, PermissionFlagsBits.KickMembers)) {
        await interaction.reply({
          content: "You need the Kick Members permission to use this command.",
          ephemeral: true,
        });
        return;
      }
      const member = interaction.options.getMember("user");
      const reason = interaction.options.getString("reason", true);
      if (!member || !("kick" in member) || typeof member.kick !== "function") {
        await interaction.reply({
          content: "That user is not a member of this server.",
          ephemeral: true,
        });
        return;
      }
      await member.kick(reason);
      await interaction.reply(`Kicked ${member.user.tag}. Reason: ${reason}`);
      return;
    }

    case "mute": {
      if (!hasPermission(interaction, PermissionFlagsBits.ModerateMembers)) {
        await interaction.reply({
          content: "You need the Moderate Members permission to use this command.",
          ephemeral: true,
        });
        return;
      }
      const member = interaction.options.getMember("user");
      const minutes = interaction.options.getInteger("minutes", true);
      const reason = interaction.options.getString("reason", true);
      if (!member || !("timeout" in member) || typeof member.timeout !== "function") {
        await interaction.reply({
          content: "That user is not a member of this server.",
          ephemeral: true,
        });
        return;
      }
      await member.timeout(minutes * 60 * 1000, reason);
      await interaction.reply(
        `Muted ${member.user.tag} for ${minutes} minute(s). Reason: ${reason}`,
      );
      return;
    }
  }
}

async function registerGuildCommands(guild: Guild): Promise<void> {
  if (!guild.client.user) return;

  const rest = new REST({ version: "10" }).setToken(botToken as string);
  await rest.put(Routes.applicationGuildCommands(guild.client.user.id, guild.id), {
    body: commands,
  });
  logger.info({ guildId: guild.id, commandCount: commands.length }, "Registered BRDRP slash commands");
}

export async function startDiscordBot(): Promise<void> {
  if (!botToken) {
    logger.warn("DISCORD_BOT_TOKEN is not set; Discord bot startup skipped");
    return;
  }

  const messageFeaturesEnabled =
    process.env["BRDRP_ENABLE_MESSAGE_FILTER"] === "true";
  const intents = [GatewayIntentBits.Guilds];
  if (messageFeaturesEnabled) {
    intents.push(GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent);
  }
  const client = new Client({ intents });
  client.once(Events.ClientReady, async (readyClient) => {
    try {
      const guild = await readyClient.guilds.fetch(guildId);
      await registerGuildCommands(guild);
      logger.info(
        { botUser: readyClient.user.tag, guildId, guildName: guild.name },
        "BRDRP Discord bot is online",
      );
    } catch (error) {
      logger.error({ err: error, guildId }, "Discord bot could not register commands");
    }
  });

  client.on(Events.InteractionCreate, (interaction) => {
    if (interaction.isChatInputCommand()) {
      void handleInteraction(interaction).catch((error) => {
        logger.error(
          { err: error, command: interaction.commandName },
          "Discord command failed",
        );
        if (interaction.replied || interaction.deferred) {
          void interaction.editReply("Something went wrong while running that command.");
        } else {
          void interaction.reply({
            content: "Something went wrong while running that command.",
            ephemeral: true,
          });
        }
      });
    }
  });

  if (messageFeaturesEnabled) {
    client.on(Events.MessageCreate, (message) => {
      if (message.author.bot || !message.guild) return;

      const blockedWord = getBlockedWords().find((word) =>
        containsBlockedWord(message.content, word),
      );
      if (blockedWord) {
        void applyWordAction(message, getWordAction()).catch((error) => {
          logger.error(
            { err: error, userId: message.author.id, blockedWord },
            "Word filter action failed",
          );
        });
        return;
      }

      const replies = getAutoReplies();
      const normalizedContent = message.content.toLocaleLowerCase();
      const replyEntry = Object.entries(replies).find(([trigger]) =>
        normalizedContent.includes(trigger.toLocaleLowerCase()),
      );
      if (replyEntry && message.channel.isSendable()) {
        void message.channel.send({ content: replyEntry[1] }).catch((error) => {
          logger.error({ err: error }, "Auto-reply failed");
        });
      }
    });
  }

  client.on("error", (error) => {
    logger.error({ err: error }, "Discord client error");
  });

  try {
    await client.login(botToken);
  } catch (error) {
    logger.error(
      { err: error },
      "Discord bot login failed; check that DISCORD_BOT_TOKEN is the bot token from the Developer Portal",
    );
  }
}