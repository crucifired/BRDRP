# BRDRP Discord Bot

Discord bot and API service for the BRDRP | Border RP Emergency Hamburg community.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/api-server/src/discord/bot.ts` — Discord client, slash commands, and permission checks.
- `BRDRP_SETUP.md` — Discord Developer Portal invite and configuration instructions.
- `artifacts/api-server/src/routes/` — API routes, including the health endpoint.

## Architecture decisions

- The Discord bot starts from the existing API service so the project has one managed runtime.
- Guild-scoped slash commands are registered on startup so new commands appear immediately in BRDRP.
- The bot token is read only from `DISCORD_BOT_TOKEN`; it is never stored in source files.

## Product

BRDRP staff can announce updates and clean up messages, while community members can view rules,
check bot status, view server information, and create Emergency Hamburg roleplay callouts.

## User preferences

The bot is for the BRDRP | Border RP Discord server and its Emergency Hamburg community.

## Gotchas

- The Replit Discord connection can identify servers but cannot run a message-handling bot.
- A separate Discord application bot token is required and must remain in Replit Secrets.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
